// routes/userRoutes.js
const express = require('express');
const { signup, login } = require('../controllers/userController');
const { body } = require('express-validator');

const router = express.Router();

router.post('/signup', [
    body('username').notEmpty(),
    body('email').isEmail(),
    body('password').isLength({ min: 6 }),
], signup);

router.post('/login', login);

module.exports = router;
